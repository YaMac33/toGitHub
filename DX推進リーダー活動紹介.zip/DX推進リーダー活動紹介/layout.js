/* =========================================================================
   layout.js — 共通レイアウト & 記事一覧の自動生成
   LGWAN / 完全オフライン / file:// 直開き / Microsoft Edge 対応
   （fetch不使用・外部リソース不使用・Shadow DOM不使用）

   ■ このファイルでやっていること
     1. 記事の一覧（ARTICLES 配列）を持つ
     2. <site-header> <site-footer> 共通のヘッダー/フッターを描画
     3. <article-list> 記事一覧を配列から自動生成

   ■ 更新担当者の方へ（ここだけ触ればOK）
     新しい記事を追加したら、下の「記事リスト（ARTICLES）」に
     1行コピーして貼り付け、中身を書き換えてください。
     それ以外の場所は触らないでください。
   ========================================================================= */

(function () {
  "use strict";

  /* =======================================================================
     ★★★ 記事リスト（ここだけ編集してください）★★★

     新しい記事を追加する手順:
       1. 下の { file: ... } の行を1つコピー
       2. いちばん上に貼り付け（新しい記事を上に並べると日付順で自然です）
       3. file / title / date を書き換える
          - file : pages/ フォルダ内のファイル名（正確に。半角英数字）
          - title: 一覧に表示される記事タイトル
          - date : 日付（YYYY-MM-DD の形式）
          - category: 今は未使用（将来カテゴリ分けする時のための欄。空 "" でOK）

     ※ カンマ「,」の付け忘れに注意。各行の末尾にカンマが必要です。
     ======================================================================= */
  const ARTICLES = [
    {
      file: "2026-07-02_dx-results.html",
      title: "DX推進リーダー これまでの取り組みと実績",
      date: "2026-07-02",
      category: ""
    }
    // ↑ 新しい記事はこの上の行にコピーして追加してください
  ];


  /* =======================================================================
     ↓↓↓ ここから下は基本的に触らないでください（仕組みの部分）↓↓↓
     ======================================================================= */

  /* --- 各ページからのパス基準 -------------------------------------------------
     ページによって index.html までの深さが違うため、base属性で指定します。
       ・トップ(index.html)や同階層     → base="."   （省略時の既定値）
       ・pages/ や info/ の中のHTML      → base=".."
     例: <site-header base="..">
     --------------------------------------------------------------------- */

  /* --- ヘッダー ----------------------------------------------------------- */
  class SiteHeader extends HTMLElement {
    connectedCallback() {
      const title = this.getAttribute("title") || "DX推進リーダー 活動紹介";
      const base = this.getAttribute("base") || ".";

      this.innerHTML = `
        <header class="navbar">
          <a href="${base}/index.html" class="brand">${escapeHtml(title)}</a>
          <nav class="flex gap-4 text-sm">
            <a href="${base}/index.html">記事一覧</a>
            <a href="${base}/info/about.html">DX推進リーダーとは？</a>
            <a href="${base}/info/contact.html">お問い合わせ先</a>
          </nav>
        </header>
      `;
    }
  }

  /* --- フッター ----------------------------------------------------------- */
  class SiteFooter extends HTMLElement {
    connectedCallback() {
      const owner = this.getAttribute("owner") || "習志野市役所 DX推進担当";
      const year = new Date().getFullYear();

      this.innerHTML = `
        <footer class="text-xs text-muted"
                style="padding: var(--space-5); margin-top: var(--space-7);
                       border-top: var(--border-hairline); text-align: center;">
          © ${year} ${escapeHtml(owner)}
        </footer>
      `;
    }
  }

  /* --- 記事一覧 ----------------------------------------------------------- */
  class ArticleList extends HTMLElement {
    connectedCallback() {
      const base = this.getAttribute("base") || ".";

      // 日付の新しい順に並べ替え（元の配列は壊さない）
      const items = ARTICLES.slice().sort(function (a, b) {
        return (b.date || "").localeCompare(a.date || "");
      });

      if (items.length === 0) {
        this.innerHTML =
          '<p class="text-muted">まだ記事がありません。</p>';
        return;
      }

      const rows = items.map(function (a) {
        return `
          <li class="article-row">
            <a class="article-link" href="${base}/pages/${encodeURI(a.file)}">
              <span class="article-date">${escapeHtml(a.date)}</span>
              <span class="article-title">${escapeHtml(a.title)}</span>
            </a>
          </li>
        `;
      }).join("");

      this.innerHTML = `<ul class="article-list">${rows}</ul>`;
    }
  }

  /* --- 簡易エスケープ ------------------------------------------------------- */
  function escapeHtml(str) {
    return String(str)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");
  }

  customElements.define("site-header", SiteHeader);
  customElements.define("site-footer", SiteFooter);
  customElements.define("article-list", ArticleList);
})();
